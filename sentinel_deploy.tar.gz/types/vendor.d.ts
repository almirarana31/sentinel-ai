declare module "canvas-confetti";

